BACI

Version: 209901

Release Date: 2099 01 01

Weblink: http://www.cepii.fr/CEPII/en/bdd_modele/bdd_modele_item.asp?id=37

Content:
SYNTHETIC TEST FIXTURE - NOT REAL DATA.
Trade flows at the year - exporter - importer - product level.
Products in Harmonized System 6-digit nomenclature.
Values in thousand USD and quantities in metric tons.

List of Variables:
t: year
i: exporter
j: importer
k: product
v: value
q: quantity

Reference:
Gaulier, G. and Zignago, S. (2010)
BACI: International Trade Database at the Product-Level. The 1994-2007 Version.
CEPII Working Paper, N°2010-23
